package com.capgemini.androidui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main_constraint.*

class MainActivity : AppCompatActivity() {
    val isRegistered = false
  //  lateinit var registerButton : Button
  //  lateinit var loginButton : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main_constraint)
        // view objects are available

//        val titleTextview : TextView = findViewById(R.id.titleT)
//        registerButton = findViewById(R.id.registerB)
//        loginButton = findViewById(R.id.loginB)


        setupButtons()

        if(isRegistered){
            titleT.text = "Please Log in"
        }else
            titleT.text = "Please Register"

    }

    fun setupButtons(){

        if(isRegistered)
            registerB.visibility = View.INVISIBLE
        else
            loginB.visibility = View.INVISIBLE
                // View.GONE - view gets removed from heierarchy
                //View.INVISIBLE // view is part of hierarchy

    }
}